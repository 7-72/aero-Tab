# aero Tab

A minimal, glass-style new tab page for Chrome. Black wallpaper with soft glowing edges, a big clock, a search bar that uses your default search engine, and a dock of shortcuts. Plain HTML, CSS and JavaScript: no framework, no build step, no tracking.

## Features

- **Greeting:** a first-run welcome, then "Good morning, *name*" through the day
- **Search:** follows Chrome's default search engine, and opens URLs directly
- **Under the search bar:** your recent tabs, or your most visited sites
- **Tab switcher:** search every open tab across windows, then jump to it or close it
- **Shortcuts:** 21 templates, add any website, remove any shortcut
- **Wallpaper:** 10 soft blurred tints plus a custom colour
- **Extras:** weather chip, 24-hour clock, Fahrenheit, quick notes

## Install

1. Clone this repo or download it as a ZIP and unzip it.
2. Open `chrome://extensions` and turn on **Developer mode**.
3. Click **Load unpacked** and select the folder that contains `manifest.json`.
4. Open a new tab.

Built for Chrome. Other Chromium browsers may work but aren't tested.

## Keyboard

| Key | Action |
| --- | --- |
| `/` | Focus the search bar |
| `T` | Open the tab switcher |
| `N` | Open or close notes |
| `Esc` | Close whatever is open |

Right-click the background, or click "aero" in the menu bar, to open settings.

## Permissions

| Permission | Used for |
| --- | --- |
| `search` | Searching with your default search engine |
| `tabs` | The tab switcher and recent tabs (reads titles and URLs of open tabs) |
| `topSites` | The "Frequent" list |
| `favicon` | Site icons for tabs and shortcuts |
| `geolocation` | Local weather |

## Privacy

Everything you set (name, shortcuts, notes, wallpaper) is stored on your device in `localStorage`. There are no accounts and no analytics. The one network request is the weather lookup, which sends your approximate coordinates to [Open-Meteo](https://open-meteo.com/).

## Customise

- Shortcut templates and wallpaper tints live at the top of `newtab.js` (`TEMPLATES`, `THEMES`).
- Icons come from [Iconify](https://iconify.design/) and are bundled in `icons.js`. To change them, edit the lists in `scripts/build-icons.js`, then run `npm install && npm run build:icons`.

## Credits

Icons: [Simple Icons](https://simpleicons.org/) (CC0) and [Lucide](https://lucide.dev/) (ISC), via Iconify. Brand logos are trademarks of their owners. Weather data by [Open-Meteo.com](https://open-meteo.com/).

## License

[MIT](LICENSE)
