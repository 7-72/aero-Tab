// Regenerates icons.js from the Iconify JSON packages.
//   npm install && npm run build:icons
const fs = require('fs');
const si = require('@iconify-json/simple-icons/icons.json');
const lu = require('@iconify-json/lucide/icons.json');

const pick = (set, names) => Object.fromEntries(
  names.filter(n => set.icons[n] || (console.warn('missing icon:', n), false)).map(n => [n, set.icons[n].body]));

const icons = {
  ...pick(si, ['youtube', 'github', 'discord', 'roblox', 'claude', 'spotify', 'gmail', 'googlemaps', 'x', 'reddit', 'twitch', 'netflix', 'whatsapp', 'telegram', 'instagram', 'tiktok', 'notion', 'figma', 'steam', 'googledrive', 'googlecalendar']),
  ...pick(lu, ['search', 'sun', 'cloud-sun', 'cloud', 'cloud-fog', 'cloud-rain', 'cloud-sun-rain', 'cloud-snow', 'cloud-lightning', 'plus', 'layers', 'sticky-note', 'x'])
};
fs.writeFileSync(__dirname + '/../icons.js', 'const ICONS=' + JSON.stringify(icons) + ';\n');
console.log(Object.keys(icons).length + ' icons written');
