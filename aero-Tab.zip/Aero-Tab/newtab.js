// Templates: [label, url, icon name from icons.js]. The first eight start on the dock.
const TEMPLATES = [
  ['YouTube', 'https://www.youtube.com', 'youtube'], ['GitHub', 'https://github.com', 'github'],
  ['Discord', 'https://discord.com/app', 'discord'], ['Roblox', 'https://www.roblox.com', 'roblox'],
  ['Claude', 'https://claude.ai', 'claude'], ['Spotify', 'https://open.spotify.com', 'spotify'],
  ['Gmail', 'https://mail.google.com', 'gmail'], ['Maps', 'https://maps.google.com', 'googlemaps'],
  ['X', 'https://x.com', 'x'], ['Reddit', 'https://www.reddit.com', 'reddit'],
  ['Twitch', 'https://www.twitch.tv', 'twitch'], ['Netflix', 'https://www.netflix.com', 'netflix'],
  ['WhatsApp', 'https://web.whatsapp.com', 'whatsapp'], ['Telegram', 'https://web.telegram.org', 'telegram'],
  ['Instagram', 'https://www.instagram.com', 'instagram'], ['TikTok', 'https://www.tiktok.com', 'tiktok'],
  ['Notion', 'https://www.notion.so', 'notion'], ['Figma', 'https://www.figma.com', 'figma'],
  ['Steam', 'https://store.steampowered.com', 'steam'], ['Drive', 'https://drive.google.com', 'googledrive'],
  ['Calendar', 'https://calendar.google.com', 'googlecalendar']
].filter(t => ICONS[t[2]]);
// name, rim light (r g b), accent glow (r g b)
const THEMES = {
  onyx: ['Onyx', '222 208 240', '120 80 200'], ice: ['Ice', '170 205 255', '60 110 230'],
  cyan: ['Cyan', '120 230 240', '20 130 170'], jade: ['Jade', '160 235 200', '20 140 100'],
  gold: ['Gold', '255 215 130', '190 110 20'], ember: ['Ember', '255 190 140', '200 70 30'],
  crimson: ['Crimson', '255 110 110', '150 20 50'], rose: ['Rose', '255 170 200', '190 60 140'],
  violet: ['Violet', '190 160 255', '90 50 200'], mono: ['Mono', '235 235 235', '110 110 120']
};

const $ = id => document.getElementById(id);
const svg = n => `<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">${ICONS[n] || ''}</svg>`;
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const host = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
const fav = u => `chrome-extension://${chrome.runtime.id}/_favicon/?pageUrl=${encodeURIComponent(u)}&size=32`;
const S = JSON.parse(localStorage.s || '{}');
const save = () => (localStorage.s = JSON.stringify(S));
const closeAll = () => document.querySelectorAll('.open:not(#welcome)').forEach(x => x.classList.remove('open'));

// dock: any shortcut can be removed, templates can be added back
let dock = JSON.parse(localStorage.dock || 'null');
if (!dock) dock = TEMPLATES.slice(0, 8).concat(JSON.parse(localStorage.links || '[]').map(l => [l[0], l[1], '']));
const glyph = d => (d[2] && ICONS[d[2]] ? svg(d[2]) : `<img src="${fav(d[1])}" alt="">`);
function saveDock() { localStorage.dock = JSON.stringify(dock); renderDock(); }
function renderDock() {
  $('dock').innerHTML = dock.map((d, i) =>
    `<a class="app" href="${esc(d[1])}" aria-label="${esc(d[0])}" data-l="${esc(d[0])}" style="--i:${i}">${glyph(d)}</a>`).join('') +
    `<button class="app add" id="add" data-l="Add shortcut" aria-label="Add shortcut">${svg('plus')}</button>`;
  $('cl').innerHTML = dock.map((d, i) =>
    `<li><span class="gl">${glyph(d)}</span><span>${esc(d[0])}</span><button data-i="${i}" aria-label="Remove ${esc(d[0])}">${svg('x')}</button></li>`).join('') || '<li class="none">No shortcuts</li>';
  $('tp').innerHTML = TEMPLATES.filter(t => !dock.some(d => d[1] === t[1])).map(t =>
    `<button data-t="${TEMPLATES.indexOf(t)}">${svg(t[2])}${t[0]}</button>`).join('') || '<span class="none">All templates added</span>';
}
$('dock').onclick = e => { if (e.target.closest('#add')) { $('sheet').classList.add('open'); $('au').focus(); } };
$('af').onsubmit = e => {
  e.preventDefault();
  let u = $('au').value.trim();
  if (!u) return;
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  if (!host(u)) return;
  dock.push([host(u), u, '']);
  $('au').value = '';
  saveDock();
};
$('cl').onclick = e => { const b = e.target.closest('button'); if (b) { dock.splice(+b.dataset.i, 1); saveDock(); } };
$('tp').onclick = e => { const b = e.target.closest('button'); if (b) { dock.push(TEMPLATES[+b.dataset.t]); saveDock(); } };
renderDock();

// icons in bar / search
$('sIcon').innerHTML = svg('search');
$('tIcon').innerHTML = svg('layers');
$('tabBtn').innerHTML = svg('layers') + '<span id="tabN"></span>';
$('noteBtn').innerHTML = svg('sticky-note');
chrome.tabs.query({}).then(t => ($('tabN').textContent = t.length));

// clock
let last = '';
function tick() {
  const d = new Date();
  const t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hourCycle: S.h24 ? 'h23' : undefined });
  if (t === last) return;
  last = t;
  greet();
  $('time').textContent = t.replace(/\s?[AP]M/i, '');
  $('date').textContent = d.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });
}
tick();
setInterval(tick, 1000);

// weather
const WX = [[0, 'Clear', 'sun'], [2, 'Partly cloudy', 'cloud-sun'], [3, 'Cloudy', 'cloud'], [48, 'Fog', 'cloud-fog'], [67, 'Rain', 'cloud-rain'], [77, 'Snow', 'cloud-snow'], [82, 'Showers', 'cloud-sun-rain'], [99, 'Thunderstorm', 'cloud-lightning']];
let wxLast = null;
function showWx(w) {
  wxLast = w;
  const c = WX.find(x => w.c <= x[0]) || WX[3];
  $('wx').title = c[1];
  $('wx').innerHTML = svg(c[2]) + Math.round(S.f ? w.t * 9 / 5 + 32 : w.t) + '°';
}
try { showWx(JSON.parse(localStorage.wx)); } catch {}
navigator.geolocation.getCurrentPosition(async ({ coords: { latitude: a, longitude: o } }) => {
  try {
    const r = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${a}&longitude=${o}&current=temperature_2m,weather_code&timezone=auto`)).json();
    const w = { t: r.current.temperature_2m, c: r.current.weather_code };
    localStorage.wx = JSON.stringify(w);
    showWx(w);
  } catch {}
}, () => {});

// search: uses the browser's default search engine
$('sf').onsubmit = e => {
  e.preventDefault();
  const q = $('q').value.trim();
  if (!q) return;
  if (!/\s/.test(q) && /^(https?:\/\/|[\w-]+(\.[\w-]+)*\.[a-z]{2,}(\/|$))/i.test(q)) {
    location.href = /^https?:/i.test(q) ? q : 'https://' + q;
  } else if (chrome.search) {
    chrome.search.query({ text: q, disposition: 'CURRENT_TAB' });
  } else {
    location.href = 'https://www.google.com/search?q=' + encodeURIComponent(q);
  }
};

// wallpaper + settings
function apply(k, rim, acc) {
  const t = THEMES[k] || [];
  rim = rim || t[1];
  acc = acc || t[2];
  const s = document.documentElement.style;
  s.setProperty('--rim', rim);
  s.setProperty('--acc', acc);
  localStorage.theme = k;
  localStorage.rim = rim;
  localStorage.acc = acc;
  document.querySelectorAll('.sw').forEach(b => b.classList.toggle('on', b.dataset.k === k));
}
$('sw').innerHTML = Object.entries(THEMES).map(([k, v]) =>
  `<button class="sw" data-k="${k}"><i style="--r:${v[1]};--a:${v[2]}"></i>${v[0]}</button>`).join('');
$('sw').onclick = e => { const b = e.target.closest('.sw'); if (b) apply(b.dataset.k); };
$('oC').oninput = e => {
  const c = [1, 3, 5].map(i => parseInt(e.target.value.slice(i, i + 2), 16));
  apply('custom', c.join(' '), c.map(v => Math.round(v * .55)).join(' '));
};
if (localStorage.theme === 'custom' && localStorage.rim) apply('custom', localStorage.rim, localStorage.acc);
else apply(THEMES[localStorage.theme] ? localStorage.theme : 'onyx');
$('o24').checked = !!S.h24;
$('oF').checked = !!S.f;
$('o24').onchange = e => { S.h24 = e.target.checked; save(); last = ''; tick(); };
$('oF').onchange = e => { S.f = e.target.checked; save(); wxLast && showWx(wxLast); };

// notes
$('nt').value = localStorage.note || '';
$('nt').oninput = () => (localStorage.note = $('nt').value);
function toggleNote() { if ($('note').classList.toggle('open')) $('nt').focus(); }
$('noteBtn').onclick = toggleNote;

// tab switcher
let all = [], shown = [], sel = 0, me = null;
async function openTabs() {
  me = await chrome.tabs.getCurrent();
  all = (await chrome.tabs.query({})).filter(t => t.id !== me?.id).sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  sel = 0;
  $('tq').value = '';
  drawTabs();
  $('tabs').classList.add('open');
  $('tq').focus();
}
function drawTabs() {
  const q = $('tq').value.toLowerCase();
  shown = all.filter(t => ((t.title || '') + ' ' + t.url).toLowerCase().includes(q));
  sel = Math.max(0, Math.min(sel, shown.length - 1));
  $('tl').innerHTML = shown.map((t, i) =>
    `<li class="${i === sel ? 'on' : ''}" data-i="${i}"><img src="${fav(t.url)}" alt=""><span class="tt">${esc(t.title || t.url)}</span><span class="tu">${esc(host(t.url))}</span><button class="x" aria-label="Close tab">${svg('x')}</button></li>`).join('') || '<li class="none">No matching tabs</li>';
  $('tl').querySelector('.on')?.scrollIntoView({ block: 'nearest' });
}
async function jump(t) {
  if (!t) return;
  await chrome.tabs.update(t.id, { active: true });
  await chrome.windows.update(t.windowId, { focused: true });
  if (me) chrome.tabs.remove(me.id);
}
$('tabBtn').onclick = openTabs;
$('tq').oninput = () => { sel = 0; drawTabs(); };
$('tq').onkeydown = e => {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); sel += e.key === 'ArrowDown' ? 1 : -1; drawTabs(); }
  else if (e.key === 'Enter') jump(shown[sel]);
};
$('tl').onclick = e => {
  const li = e.target.closest('li[data-i]');
  if (!li) return;
  const t = shown[+li.dataset.i];
  if (e.target.closest('.x')) { chrome.tabs.remove(t.id); all = all.filter(x => x.id !== t.id); drawTabs(); }
  else jump(t);
};

// greeting, welcome, recent / frequent
function greet() {
  const h = new Date().getHours();
  const g = h >= 5 && h < 12 ? 'Good morning' : h >= 12 && h < 17 ? 'Good afternoon' : h >= 17 && h < 22 ? 'Good evening' : 'Good night';
  $('hello').textContent = S.name ? `${g}, ${S.name}` : g;
}
greet();
$('on').value = S.name || '';
$('on').oninput = () => { S.name = $('on').value.trim().slice(0, 24); save(); greet(); };
function finishWelcome(name) {
  S.name = name.trim().slice(0, 24);
  S.welcomed = true;
  save();
  $('on').value = S.name;
  $('welcome').classList.remove('open');
  greet();
}
$('wf').onsubmit = e => { e.preventDefault(); finishWelcome($('wn').value); };
$('ws').onclick = () => finishWelcome('');
if (!S.welcomed) { $('welcome').classList.add('open'); setTimeout(() => $('wn').focus(), 450); }

let recItems = [];
async function drawRec() {
  const m = S.m || 'recent';
  let items = [];
  try {
    if (m === 'top') {
      items = (await chrome.topSites.get()).slice(0, 6);
    } else {
      me = await chrome.tabs.getCurrent();
      items = (await chrome.tabs.query({}))
        .filter(t => t.id !== me?.id && /^https?:/.test(t.url || ''))
        .sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))
        .slice(0, 6).map(t => ({ title: t.title, url: t.url, tab: t }));
    }
  } catch {}
  recItems = items;
  $('chips').innerHTML = items.map((x, i) =>
    `<a class="rc" href="${esc(x.url)}" data-i="${i}" title="${esc(x.url)}"><img src="${fav(x.url)}" alt=""><span>${esc(x.title || host(x.url))}</span></a>`).join('') ||
    `<span class="none">${m === 'top' ? 'Nothing here yet' : 'No other tabs open'}</span>`;
  document.querySelectorAll('#seg button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
}
$('seg').onclick = e => { const b = e.target.closest('button'); if (b) { S.m = b.dataset.m; save(); drawRec(); } };
$('chips').onclick = e => {
  const a = e.target.closest('a');
  if (a && recItems[+a.dataset.i]?.tab) { e.preventDefault(); jump(recItems[+a.dataset.i].tab); }
};
drawRec();

// overlays + shortcuts (/ search, T tabs, N notes)
$('logo').onclick = () => $('sheet').classList.add('open');
document.querySelectorAll('.sheet:not(#welcome)').forEach(s => (s.onclick = e => { if (e.target === s) s.classList.remove('open'); }));
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeAll(); document.activeElement.blur(); return; }
  if (/INPUT|TEXTAREA/.test(document.activeElement.tagName) || e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.key === '/') { e.preventDefault(); $('q').focus(); }
  else if (e.key === 't') { e.preventDefault(); openTabs(); }
  else if (e.key === 'n') { e.preventDefault(); toggleNote(); }
});
document.addEventListener('contextmenu', e => {
  if (!e.target.closest('a,input,textarea,.panel')) { e.preventDefault(); $('sheet').classList.add('open'); }
});
